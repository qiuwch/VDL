# Code to control the OWI arm (real and virtual)

Do `pip install roboarm`

If [no backend error](http://stackoverflow.com/questions/13773132/pyusb-on-windows-no-backend-available).

## Related links
- [nvbn/roboarm, python library](https://github.com/nvbn/roboarm)
- [haroldl/owi, c library](https://github.com/haroldl/owi)
