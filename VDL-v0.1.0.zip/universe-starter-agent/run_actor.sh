python actor.py --server_ip `hostname` --env-id flashgames.NeonRace-v0 --remotes "vnc://localhost:13001+15901" &
python actor.py --server_ip `hostname` --env-id flashgames.NeonRace-v0 --remotes "vnc://localhost:13000+15900" &
