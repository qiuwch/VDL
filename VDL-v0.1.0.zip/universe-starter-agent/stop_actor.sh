kill -9 `ps aux | grep actor.py | awk '{print $2}'`
