python ps_run.py --job-name ps --env-id flashgames.NeonRace-v0 --log-dir train-log/ps-`hostname` 
