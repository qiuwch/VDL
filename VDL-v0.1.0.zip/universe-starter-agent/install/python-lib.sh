pip install --user gym
pip install --user --upgrade https://storage.googleapis.com/tensorflow/linux/cpu/tensorflow-1.0.1-cp27-none-linux_x86_64.whl
pip install --user txaio
pip install --user --upgrade pyopenssl
pip install --user backports.ssl_match_hostname
pip install --user --upgrade urllib3
pip install --user websocket
