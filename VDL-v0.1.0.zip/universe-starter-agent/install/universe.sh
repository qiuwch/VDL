sudo apt install cmake
pip install --user "gym[atari]"
sudo add-apt-repository ppa:ubuntu-lxc/lxd-stable
sudo apt-get update
sudo apt-get install golang
git clone https://github.com/openai/universe.git
cd universe
pip install --user -e .
